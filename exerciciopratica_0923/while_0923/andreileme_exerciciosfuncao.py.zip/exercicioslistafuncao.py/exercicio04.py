def area_quadrado(lado):
    area = lado ** 2
    return area

lado1 = 4
lado2 = 9

print(f'A área do quadrado com lado {lado1} é {area_quadrado(lado1)}')  
print(f'A área do quadrado com lado {lado2} é {area_quadrado(lado2)}')  
