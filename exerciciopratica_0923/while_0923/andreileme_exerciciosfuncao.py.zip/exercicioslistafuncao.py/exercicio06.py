def area_triangulo(base, altura):
    area = (base * altura) / 2
    return area

base1 = 6
altura1 = 9
print(f'A área do triângulo com base {base1} e altura {altura1} é {area_triangulo(base1, altura1)}')  

base2 = 5
altura2 = 8
print(f'A área do triângulo com base {base2} e altura {altura2} é {area_triangulo(base2, altura2)}')  
