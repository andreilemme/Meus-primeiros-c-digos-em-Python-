número = 1
while número <= 10:
    print (número)
    número += 1