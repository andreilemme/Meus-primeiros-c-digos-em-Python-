N = int(input("Digite um número inteiro positivo para iniciar a contagem regressiva: "))

while N >= 0:
    print(N)
    N -= 1 
