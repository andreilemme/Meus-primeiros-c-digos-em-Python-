# Usa um laço for para exibir os quadrados dos números de 1 a 10
for i in range(1, 11):
    print(f"O quadrado de {i} é {i ** 2}")
