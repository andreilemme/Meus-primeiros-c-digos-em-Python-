N = int(input("Digite um número inteiro positivo: "))

potencia = 1

while potencia <= N:
    print(potencia)
    potencia *= 2
